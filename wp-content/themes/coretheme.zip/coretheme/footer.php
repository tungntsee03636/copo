
<?php
?>
<!--            FOOTER-->
     <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/assets/js/main.js"></script>
     <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<?php wp_footer(); ?>
</body>
</html>