<?php get_header(); ?>

    <div id="main-content">

    </div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>