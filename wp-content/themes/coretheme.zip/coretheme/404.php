
<?php 
 get_header();
?>
<a href="<?php echo get_home_url(); ?>">
    <img style="width:100%" src="https://blog.minnano-tokugi.com/wp-content/uploads/2023/06/opps.png">
</a>


<?php get_footer();?>